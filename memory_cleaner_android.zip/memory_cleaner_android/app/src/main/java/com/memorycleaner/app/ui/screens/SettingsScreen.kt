package com.memorycleaner.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CalendarViewWeek
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorycleaner.app.ui.components.CuteRobot
import com.memorycleaner.app.ui.theme.PurplePrimary

enum class ScheduleType { WEEKLY, MONTHLY, OFF }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    var schedule by remember { mutableStateOf(ScheduleType.WEEKLY) }
    var notify by remember { mutableStateOf(true) }
    var autoOpen by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "برگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8F9FF))
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CuteRobot(
                size = 100.dp,
                showSpeech = true,
                speechText = "اینجا می‌تونی زمان‌بندی رو تنظیم کنی!"
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "فاصله پاکسازی خودکار",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(12.dp))

            ScheduleOption(
                title = "هر هفته",
                subtitle = "یک‌بار در هفته حافظه پاکسازی می‌شه",
                icon = Icons.Rounded.CalendarViewWeek,
                selected = schedule == ScheduleType.WEEKLY,
                onClick = { schedule = ScheduleType.WEEKLY }
            )
            Spacer(modifier = Modifier.height(10.dp))
            ScheduleOption(
                title = "هر ماه",
                subtitle = "یک‌بار در ماه حافظه پاکسازی می‌شه",
                icon = Icons.Rounded.CalendarMonth,
                selected = schedule == ScheduleType.MONTHLY,
                onClick = { schedule = ScheduleType.MONTHLY }
            )
            Spacer(modifier = Modifier.height(10.dp))
            ScheduleOption(
                title = "خاموش",
                subtitle = "فقط پاکسازی دستی انجام بشه",
                icon = Icons.Rounded.PowerSettingsNew,
                selected = schedule == ScheduleType.OFF,
                onClick = { schedule = ScheduleType.OFF }
            )

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "سایر تنظیمات",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(8.dp))

            SwitchRow(
                title = "اعلان بعد از پاکسازی",
                subtitle = "بعد از هر پاکسازی موفق بهت خبر بدم",
                checked = notify,
                onCheckedChange = { notify = it }
            )
            SwitchRow(
                title = "هدایت به تنظیمات برنامه",
                subtitle = "برای پاکسازی کامل‌تر، صفحه تنظیمات برنامه رو باز کن",
                checked = autoOpen,
                onCheckedChange = { autoOpen = it }
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "نسخه ۱.۰.۰ • ساخته شده با ❤️",
                color = Color.Gray,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun ScheduleOption(
    title: String,
    subtitle: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) PurplePrimary else Color.LightGray.copy(alpha = 0.5f),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) PurplePrimary.copy(alpha = 0.08f) else Color.White
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (selected) PurplePrimary else PurplePrimary.copy(alpha = 0.1f),
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = if (selected) Color.White else PurplePrimary
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    color = if (selected) PurplePrimary else Color(0xFF2D3436)
                )
                Text(text = subtitle, fontSize = 12.sp, color = Color.Gray)
            }
            if (selected) {
                Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = PurplePrimary)
            }
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, fontSize = 12.sp, color = Color.Gray)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = PurplePrimary)
        )
    }
}
