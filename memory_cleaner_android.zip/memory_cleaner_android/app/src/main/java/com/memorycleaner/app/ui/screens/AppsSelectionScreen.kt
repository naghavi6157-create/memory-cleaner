package com.memorycleaner.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorycleaner.app.ui.theme.PurplePrimary

data class AppItem(
    val name: String,
    val packageName: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsSelectionScreen(onBack: () -> Unit) {
    // لیست نمونه (در نسخه واقعی از PackageManager گرفته می‌شود)
    val allApps = remember {
        listOf(
            AppItem("اینستاگرام", "com.instagram.android"),
            AppItem("تلگرام", "org.telegram.messenger"),
            AppItem("واتساپ", "com.whatsapp"),
            AppItem("کروم", "com.android.chrome"),
            AppItem("یوتیوب", "com.google.android.youtube"),
            AppItem("اسنپ", "cab.snapp.passenger"),
            AppItem("دیجی‌کالا", "com.digikala.android"),
            AppItem("گالری", "com.google.android.apps.photos"),
            AppItem("فایل‌منیجر", "com.google.android.apps.nbu.files"),
            AppItem("نقشه گوگل", "com.google.android.apps.maps"),
            AppItem("توییتر / X", "com.twitter.android"),
            AppItem("روبیکا", "app.rubika.android"),
        )
    }

    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<String>()) }

    val filtered = allApps.filter {
        it.name.contains(search, ignoreCase = true) ||
                it.packageName.contains(search, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("انتخاب برنامه‌ها", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "برگشت")
                    }
                },
                actions = {
                    TextButton(onClick = {
                        selected = allApps.map { it.packageName }.toSet()
                    }) {
                        Text("همه")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8F9FF))
                .padding(padding)
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                placeholder = { Text("جستجوی برنامه...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = PurplePrimary
                )
            )

            Text(
                text = "برنامه‌هایی که انتخاب می‌کنی، در پاکسازی‌های خودکار و دستی در اولویت قرار می‌گیرن.",
                fontSize = 13.sp,
                color = Color.Gray,
                modifier = Modifier.padding(16.dp)
            )

            LazyColumn(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filtered) { app ->
                    val isSelected = selected.contains(app.packageName)
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White,
                        shadowElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = PurplePrimary.copy(alpha = 0.12f),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = app.name.firstOrNull()?.toString() ?: "?",
                                        fontWeight = FontWeight.Bold,
                                        color = PurplePrimary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = app.name, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = app.packageName,
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = {
                                    selected = if (it) {
                                        selected + app.packageName
                                    } else {
                                        selected - app.packageName
                                    }
                                },
                                colors = CheckboxDefaults.colors(checkedColor = PurplePrimary)
                            )
                        }
                    }
                }
            }
        }
    }
}
