package com.memorycleaner.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.memorycleaner.app.ui.components.CuteRobot
import com.memorycleaner.app.ui.theme.PurplePrimary

data class PermissionItem(
    val icon: ImageVector,
    val title: String,
    val description: String
)

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PermissionScreen(onContinue: () -> Unit) {
    val permissions = buildList {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
        // بقیه دسترسی‌ها در زمان نیاز درخواست می‌شوند
    }

    val permissionState = rememberMultiplePermissionsState(permissions)
    var isRequesting by remember { mutableStateOf(false) }

    val items = listOf(
        PermissionItem(
            Icons.Rounded.Storage,
            "دسترسی به حافظه",
            "برای اسکن و پاکسازی فایل‌های موقت و کش"
        ),
        PermissionItem(
            Icons.Rounded.Apps,
            "مشاهده برنامه‌ها",
            "برای نشان دادن لیست برنامه‌ها و مدیریت کش آن‌ها"
        ),
        PermissionItem(
            Icons.Rounded.Notifications,
            "اعلان‌ها",
            "برای خبر دادن بعد از هر پاکسازی موفق"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FF))
            .padding(horizontal = 20.dp)
            .statusBarsPadding()
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        CuteRobot(
            size = 130.dp,
            showSpeech = true,
            speechText = "برای کمک بهت، چند دسترسی لازم دارم 🙏"
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "دسترسی‌های مورد نیاز",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF2D3436)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "این دسترسی‌ها فقط برای پاکسازی حافظه استفاده می‌شن و هیچ اطلاعاتی جمع‌آوری نمی‌شه.",
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 12.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items) { item ->
                PermissionCard(item)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                isRequesting = true
                if (permissionState.allPermissionsGranted || permissions.isEmpty()) {
                    onContinue()
                } else {
                    permissionState.launchMultiplePermissionRequest()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
        ) {
            if (isRequesting && !permissionState.allPermissionsGranted) {
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(22.dp)
                )
            } else {
                Text(
                    text = "اجازه می‌دم و ادامه می‌دم",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        TextButton(onClick = onContinue) {
            Text("فعلاً رد شو (با امکانات محدود)", color = Color.Gray)
        }

        Spacer(modifier = Modifier.height(12.dp))
    }

    // وقتی دسترسی داده شد برو صفحه بعد
    LaunchedEffect(permissionState.allPermissionsGranted) {
        if (permissionState.allPermissionsGranted && isRequesting) {
            onContinue()
        }
    }
}

@Composable
private fun PermissionCard(item: PermissionItem) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PurplePrimary.copy(alpha = 0.12f),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = null,
                        tint = PurplePrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = item.description,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
