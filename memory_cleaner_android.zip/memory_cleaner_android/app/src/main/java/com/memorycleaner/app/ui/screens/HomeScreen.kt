package com.memorycleaner.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorycleaner.app.ui.components.CuteRobot
import com.memorycleaner.app.ui.theme.PurplePrimary
import com.memorycleaner.app.ui.theme.TealSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    onSettingsClick: () -> Unit,
    onAppsClick: () -> Unit
) {
    var isCleaning by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("آماده برای پاکسازی!") }
    var progress by remember { mutableFloatStateOf(0f) }
    val scope = rememberCoroutineScope()

    val animatedProgress by animateFloatAsState(targetValue = progress, label = "progress")

    fun startCleanup() {
        if (isCleaning) return
        scope.launch {
            isCleaning = true
            statusMessage = "دارم حافظه رو اسکن می‌کنم..."
            progress = 0.15f
            delay(700)

            statusMessage = "در حال پاکسازی کش برنامه‌ها..."
            progress = 0.45f
            delay(900)

            statusMessage = "در حال بهینه‌سازی..."
            progress = 0.8f
            delay(600)

            progress = 1f
            statusMessage = "پاکسازی انجام شد! 🎉"
            isCleaning = false

            // در نسخه واقعی اینجا سرویس پاکسازی صدا زده می‌شود
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FF))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // هدر
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "سلام! 👋",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.weight(1f))
            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White)
            ) {
                Icon(Icons.Rounded.Settings, contentDescription = "تنظیمات")
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CuteRobot(
                size = 160.dp,
                isHappy = !isCleaning,
                isWorking = isCleaning,
                showSpeech = true,
                speechText = if (isCleaning) "دارم کار می‌کنم... 💪" else "حافظه‌ات رو تمیز نگه می‌دارم!",
                onClick = { startCleanup() }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // کارت وضعیت
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.White,
                shadowElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = statusMessage,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                    if (isCleaning) {
                        Spacer(modifier = Modifier.height(14.dp))
                        LinearProgressIndicator(
                            progress = { animatedProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = PurplePrimary,
                            trackColor = PurplePrimary.copy(alpha = 0.15f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // دکمه‌ها
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.CleaningServices,
                    title = "پاکسازی الان",
                    color = PurplePrimary,
                    onClick = { startCleanup() }
                )
                ActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Apps,
                    title = "انتخاب برنامه‌ها",
                    color = TealSecondary,
                    onClick = onAppsClick
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // زمان‌بندی
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = PurplePrimary.copy(alpha = 0.08f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Schedule, contentDescription = null, tint = PurplePrimary)
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("پاکسازی خودکار", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("هر هفته یک‌بار", fontSize = 13.sp, color = Color.Gray)
                    }
                    TextButton(onClick = onSettingsClick) {
                        Text("تغییر")
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // نکته
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFFFFF8E7),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        Icons.Rounded.Info,
                        contentDescription = null,
                        tint = Color(0xFFE6A817),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "به دلیل محدودیت‌های اندروید، پاکسازی کامل کش بعضی برنامه‌ها نیاز به تأیید دستی شما در تنظیمات سیستم داره. ربات کمکت می‌کنه سریع‌تر بری اونجا.",
                        fontSize = 12.5.sp,
                        color = Color(0xFF5D4E37),
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ActionCard(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 20.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = color.copy(alpha = 0.12f),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(26.dp))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = color
            )
        }
    }
}
