package com.memorycleaner.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorycleaner.app.ui.theme.PurplePrimary
import com.memorycleaner.app.ui.theme.SoftPink
import com.memorycleaner.app.ui.theme.TealSecondary
import kotlin.math.sin

@Composable
fun CuteRobot(
    modifier: Modifier = Modifier,
    size: Dp = 180.dp,
    isHappy: Boolean = true,
    isWorking: Boolean = false,
    showSpeech: Boolean = false,
    speechText: String = "سلام! من میمو هستم ✨",
    onClick: (() -> Unit)? = null
) {
    // انیمیشن شناور بودن
    val infiniteTransition = rememberInfiniteTransition(label = "robot")

    val floatOffset by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float"
    )

    // آنتن
    val antennaBounce by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "antenna"
    )

    // پلک زدن
    var blink by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay((2000..4500).random().toLong())
            blink = 1f
            kotlinx.coroutines.delay(120)
            blink = 0f
        }
    }

    // تکان خوردن وقتی کار می‌کنه
    val workOffset by infiniteTransition.animateFloat(
        initialValue = if (isWorking) -3f else 0f,
        targetValue = if (isWorking) 3f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "work"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showSpeech) {
            SpeechBubble(text = speechText)
            Spacer(modifier = Modifier.height(8.dp))
        }

        Box(
            modifier = Modifier
                .size(size)
                .offset(x = workOffset.dp, y = floatOffset.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.toPx()
                val h = size.toPx()
                val centerX = w / 2
                val centerY = h / 2

                // سایه
                drawOval(
                    color = Color.Black.copy(alpha = 0.08f),
                    topLeft = Offset(centerX - w * 0.28f, h * 0.88f),
                    size = Size(w * 0.56f, h * 0.08f)
                )

                // بدن
                val bodyColor = if (isWorking) {
                    Brush.linearGradient(listOf(TealSecondary, Color(0xFF00B4A0)))
                } else {
                    Brush.linearGradient(listOf(PurplePrimary, Color(0xFF5A52E0)))
                }

                drawRoundRect(
                    brush = bodyColor,
                    topLeft = Offset(centerX - w * 0.29f, centerY + h * 0.02f),
                    size = Size(w * 0.58f, h * 0.46f),
                    cornerRadius = CornerRadius(28f, 28f)
                )

                // براق بدن
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.22f),
                    topLeft = Offset(centerX - w * 0.24f, centerY + h * 0.06f),
                    size = Size(w * 0.22f, h * 0.14f),
                    cornerRadius = CornerRadius(12f, 12f)
                )

                // سر
                val headRadius = w * 0.30f
                val headCenter = Offset(centerX, centerY - h * 0.16f)

                drawCircle(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF8B83FF), PurplePrimary)
                    ),
                    radius = headRadius,
                    center = headCenter
                )

                // آنتن چپ
                drawAntenna(headCenter, headRadius, -1f, antennaBounce)
                // آنتن راست
                drawAntenna(headCenter, headRadius, 1f, antennaBounce)

                // چشم‌ها
                val eyeY = headCenter.y - headRadius * 0.08f
                val eyeSpacing = headRadius * 0.38f
                val eyeHeight = headRadius * 0.26f * (1f - blink * 0.92f)

                drawEye(Offset(headCenter.x - eyeSpacing, eyeY), headRadius * 0.20f, eyeHeight)
                drawEye(Offset(headCenter.x + eyeSpacing, eyeY), headRadius * 0.20f, eyeHeight)

                // گونه
                drawCircle(
                    color = SoftPink.copy(alpha = 0.45f),
                    radius = headRadius * 0.11f,
                    center = Offset(headCenter.x - headRadius * 0.52f, headCenter.y + headRadius * 0.18f)
                )
                drawCircle(
                    color = SoftPink.copy(alpha = 0.45f),
                    radius = headRadius * 0.11f,
                    center = Offset(headCenter.x + headRadius * 0.52f, headCenter.y + headRadius * 0.18f)
                )

                // دهان
                val mouthPath = Path().apply {
                    if (isHappy) {
                        moveTo(headCenter.x - headRadius * 0.20f, headCenter.y + headRadius * 0.28f)
                        quadraticBezierTo(
                            headCenter.x,
                            headCenter.y + headRadius * 0.42f,
                            headCenter.x + headRadius * 0.20f,
                            headCenter.y + headRadius * 0.28f
                        )
                    } else {
                        moveTo(headCenter.x - headRadius * 0.16f, headCenter.y + headRadius * 0.32f)
                        lineTo(headCenter.x + headRadius * 0.16f, headCenter.y + headRadius * 0.32f)
                    }
                }
                drawPath(
                    path = mouthPath,
                    color = Color(0xFF2D3436),
                    style = Stroke(width = 4f, cap = StrokeCap.Round)
                )

                // نقطه کار کردن روی سینه
                if (isWorking) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.9f),
                        radius = 7f,
                        center = Offset(centerX, centerY + h * 0.12f)
                    )
                    drawCircle(
                        color = TealSecondary,
                        radius = 4.5f,
                        center = Offset(centerX, centerY + h * 0.12f)
                    )
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAntenna(
    headCenter: Offset,
    headRadius: Float,
    side: Float,
    bounce: Float
) {
    val base = Offset(
        headCenter.x + side * headRadius * 0.52f,
        headCenter.y - headRadius * 0.68f
    )

    // پایه
    drawRoundRect(
        color = Color(0xFF5A52E0),
        topLeft = Offset(base.x - 3f, base.y - 10f),
        size = Size(6f, 18f),
        cornerRadius = CornerRadius(3f, 3f)
    )

    // توپ آنتن
    drawCircle(
        color = SoftPink,
        radius = 7f,
        center = Offset(base.x, base.y - 14f - bounce)
    )
    // هایلایت
    drawCircle(
        color = Color.White.copy(alpha = 0.6f),
        radius = 2.5f,
        center = Offset(base.x - 2f, base.y - 16f - bounce)
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawEye(
    center: Offset,
    width: Float,
    height: Float
) {
    // سفیدی
    drawOval(
        color = Color.White,
        topLeft = Offset(center.x - width * 0.85f, center.y - height * 0.75f),
        size = Size(width * 1.7f, height * 1.5f)
    )
    // مردمک
    drawCircle(
        color = Color(0xFF2D3436),
        radius = width * 0.52f,
        center = center
    )
    // هایلایت
    drawCircle(
        color = Color.White,
        radius = width * 0.20f,
        center = Offset(center.x - width * 0.18f, center.y - width * 0.18f)
    )
}

@Composable
private fun SpeechBubble(text: String) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        shadowElevation = 6.dp
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF2D3436),
            textAlign = TextAlign.Center
        )
    }
}
