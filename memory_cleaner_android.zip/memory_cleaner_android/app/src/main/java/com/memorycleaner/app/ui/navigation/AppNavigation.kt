package com.memorycleaner.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.memorycleaner.app.ui.screens.*

sealed class Screen(val route: String) {
    data object Splash : Screen("splash")
    data object Permission : Screen("permission")
    data object Home : Screen("home")
    data object Settings : Screen("settings")
    data object AppsSelection : Screen("apps_selection")
}

@Composable
fun AppNavigation(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onFinished = {
                    // در نسخه واقعی اینجا چک می‌کنیم که دسترسی داده شده یا نه
                    navController.navigate(Screen.Permission.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Permission.route) {
            PermissionScreen(
                onContinue = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Permission.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                onSettingsClick = { navController.navigate(Screen.Settings.route) },
                onAppsClick = { navController.navigate(Screen.AppsSelection.route) }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.AppsSelection.route) {
            AppsSelectionScreen(onBack = { navController.popBackStack() })
        }
    }
}
